# SmallBiz Website Kit

## 5 Premium Website Templates for Local Businesses

Thank you for purchasing! Here's everything you need to get started.

---

## What's Included

| Template | Folder | Best For |
|----------|--------|----------|
| The Bistro | `/templates/restaurant/` | Restaurants, cafes, bars, bakeries |
| The Studio | `/templates/salon/` | Hair salons, barbers, beauty, spas |
| The Builder | `/templates/contractor/` | Contractors, handymen, plumbers, electricians |
| The Gym | `/templates/fitness/` | Gyms, personal trainers, yoga studios |
| The Firm | `/templates/professional/` | Lawyers, accountants, consultants, realtors |

---

## Quick Start (5 minutes)

1. Open any template folder
2. Open `index.html` in your browser to preview it
3. Open `index.html` in any text editor (VS Code, Notepad, TextEdit)
4. Look for the comments at the top of the file — they tell you exactly what to change
5. Edit the business name, phone, address, colors, and content
6. Upload to your hosting provider

---

## How to Customize

Each template has a customization guide built into the HTML comments at the very top of the file. Look for lines like:

```
<!-- CUSTOMIZATION GUIDE
  Business Name: Change "The Bistro" to your restaurant name
  Phone: Replace "(555) 123-4567" with your number
  Colors: Change #D4A574 to your brand color
  ...
-->
```

### Changing Colors
Search for the color hex codes mentioned in the guide and replace them with your brand colors.

### Changing Content
All text is plain HTML — just find and replace.

### Adding Your Logo
Replace the text logo in the header with an `<img>` tag pointing to your logo file.

### Adding Real Photos
Replace the gradient/placeholder backgrounds with your own images using CSS `background-image: url('your-photo.jpg')`.

---

## How to Deploy (Free Options)

### Netlify (Recommended — Free)
1. Go to netlify.com and sign up
2. Drag and drop your template folder onto the page
3. Done — you get a free URL instantly
4. Connect your own domain for free

### GitHub Pages (Free)
1. Create a GitHub repository
2. Upload your template files
3. Enable GitHub Pages in settings

### Any Web Hosting
Just upload the HTML file and any images to your hosting via FTP or file manager.

---

## Support

Questions? Email jeff@thecodingpit.com

---

## License

You may use these templates for unlimited personal and client projects. You may NOT resell the templates themselves as a template product.
